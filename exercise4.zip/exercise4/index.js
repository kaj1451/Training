//1.  local storage .. save
function setTheme(theme) {
    document.body.className = theme;
    localStorage.setItem("theme", theme);
  }
 
  // Load theme on page load
  window.onload = function () {
    const savedTheme = localStorage.getItem("theme");
    if (savedTheme) {
      document.body.className = savedTheme;
    }
  };
 
//2. ES6 Feature
const cartItems = [
  { name: "Shirt", price: 200 },
  { name: "Pant", price: 500 },
  { name: "Shoes", price: 100 },
];
 
const total = cartItems.reduce((sum, item) => sum + item.price, 0);
console.log(`Total Price: Rs.${total}`);
 
//4. Fetch API
window.onload = () => {
  fetch("https://jsonplaceholder.typicode.com/users")
    .then((response) => response.json())
    .then((users) => {
      const { name, email }= users[0];
      console.log(`Name: ${name}, Email: ${email}`);
    })
 
    .catch((error) => console.error("Error fetching data:", error));
};
import { add, sub, mul, div } from './mathUtils.js';

console.log(add(5, 3)); 
console.log(mul(4, 2)); 
console.log(sub(8, 2));
console.log(div(8, 2));

import React from 'react';
import ProfileList from './ProfileList';
 
function App() {
  return (
    <div className="App">
      <ProfileList />
    </div>
  );
}
 
export default App;